<?php  
class ControllerModuleDresscodebanner extends Controller {
	protected function index($setting) {
		static $module = 0;
		
		$this->load->model('design/banner');
		$this->load->model('tool/image');

        $this->data['buyshop_general_settings'] = $this->config->get('bs_general');


        $this->document->addScript('catalog/view/theme/' . $this->config->get('config_template') . '/js/responsiveslides.js');

        if (isset($this->data['buyshop_general_settings']['response'])) {
            if ($this->data['buyshop_general_settings']['response'] !== 'disable') {
                $this->document->addScript('catalog/view/theme/' . $this->config->get('config_template') . '/js/banner_scripts.js');
            } else {
                $this->document->addScript('catalog/view/theme/' . $this->config->get('config_template') . '/js/banner_scripts_off.js');
            }
        } else {
            $this->document->addScript('catalog/view/theme/' . $this->config->get('config_template') . '/js/banner_scripts.js');
        }

        $this->data['banners'] = array();
		
		$results = $this->model_design_banner->getBanner($setting['banner_id']);
		  
		foreach ($results as $result) {
			if (file_exists(DIR_IMAGE . $result['image'])) {
				$this->data['banners'][] = array(
					'title' => $result['title'],
					'link'  => $result['link'],
					'image' => $this->model_tool_image->resize($result['image'], $setting['width'], $setting['height'])
				);
			}
		}
		
		$this->data['module'] = $module++;
				
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/dresscode_banner.tpl')) {
			$this->template = $this->config->get('config_template') . '/template/module/dresscode_banner.tpl';
		} else {
			$this->template = 'default/template/module/dresscode_banner.tpl';
		}
		
		$this->render();
	}
}
?>