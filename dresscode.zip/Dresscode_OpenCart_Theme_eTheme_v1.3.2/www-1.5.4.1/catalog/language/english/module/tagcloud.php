<?php
// Heading
$_['heading_title']   = 'Tags';

$_['text_notags']     = 'No tags available';
$_['text_href_title'] = 'products tagged with';
