<?php
// Heading 
$_['heading_title'] = 'Special Products';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>