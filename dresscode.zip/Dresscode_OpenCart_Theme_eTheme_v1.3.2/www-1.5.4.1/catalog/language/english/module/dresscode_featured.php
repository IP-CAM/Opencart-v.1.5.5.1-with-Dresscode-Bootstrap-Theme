<?php
// Heading 
$_['heading_title'] = 'Deal of the Day';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>