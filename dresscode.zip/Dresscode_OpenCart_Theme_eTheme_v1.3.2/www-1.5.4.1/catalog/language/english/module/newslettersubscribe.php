<?php
// Heading 
$_['heading_title'] 	 = 'Newsletter signup';

//Fields
$_['entry_email'] 		 = 'Email';
$_['entry_name'] 		 = 'Name';

//Buttons
$_['entry_button'] 		 = 'Subscribe';
$_['entry_unbutton'] 	 = 'Unsubscribe';

//text
$_['text_subscribe'] 	 = 'Subscribe Here';

$_['mail_subject']   	 = 'News Letter Subscribe';

//Error
$_['error_invalid'] 	 = 'You have entered invalid email!';

$_['subscribe']	    	 = 'You have been subscribed!!!';
$_['unsubscribe'] 	     = 'Unsubscribed Successfully';
$_['alreadyexist'] 	     = 'This email already exist!';
$_['notexist'] 	    	 = 'Email Id not exist';

?>