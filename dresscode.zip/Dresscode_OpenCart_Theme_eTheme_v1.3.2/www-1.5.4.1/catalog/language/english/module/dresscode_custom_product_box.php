<?php
$_['heading_title'] = 'PRODUCT CUSTOM BLOCK';
?>