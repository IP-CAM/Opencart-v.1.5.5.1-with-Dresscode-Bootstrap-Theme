<?php
$_['heading_title'] = 'MENU CUSTOM TITLE';
?>