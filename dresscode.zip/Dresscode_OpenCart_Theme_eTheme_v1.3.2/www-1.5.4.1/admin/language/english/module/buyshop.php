<?php
/**
 * Created by JetBrains PhpStorm.
 * User: luka
 * Date: 19.12.12
 * Time: 9:57
 * To change this template use File | Settings | File Templates.
 */
// Heading
$_['heading_title'] = 'Dresscode Theme Admin Panel';

$_['module_intro'] = 'Edit Dresscode Theme features here';

// Text
$_['text_success']        = 'Success: You have modified the module!';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify the module!';


