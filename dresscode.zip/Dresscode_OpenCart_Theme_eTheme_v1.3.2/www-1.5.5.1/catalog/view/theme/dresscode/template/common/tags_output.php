<?php echo $flash_title; ?>
<tags>
	<a href="index?route=product/category&path=34;" class="tag-link-200" rel="tag" style="font-size: 20pt;" color="0x000000">Clothes</a>
    <a href="index?route=product/category&path=24;" class="tag-link-200" rel="tag" style="font-size: 20pt;" color="0x000000">Jackets</a>
    <a href="index?route=product/category&path=33;" class="tag-link-200" rel="tag" style="font-size: 20pt;" color="0x000000">Dresses</a>
    <a href="index?route=product/category&path=17;" class="tag-link-200" rel="tag" style="font-size: 20pt;" color="0x000000">Skirts</a>
    <a href="index?route=product/category&path=34;" class="tag-link-200" rel="tag" style="font-size: 20pt;" color="0x000000">Shorts</a>
    <a href="index?route=product/category&path=57;" class="tag-link-200" rel="tag" style="font-size: 20pt;" color="0x000000">Bras</a>
    <a href="index?route=product/category&path=25;" class="tag-link-200" rel="tag" style="font-size: 20pt;" color="0x000000">Coats</a>
    <a href="index?route=product/category&path=18;" class="tag-link-200" rel="tag" style="font-size: 20pt;" color="0x000000">Jeans</a>
</tags>




