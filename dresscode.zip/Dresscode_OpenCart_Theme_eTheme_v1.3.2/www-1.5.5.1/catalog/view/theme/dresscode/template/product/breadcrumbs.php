<div class="sixteen columns breadcrumb">
    <?php foreach ($breadcrumbs as $breadcrumb) { ?>
    	<a href="<?php echo $breadcrumb['href']; ?>"><?php echo $breadcrumb['text']; ?></a>
    <?php } ?>
</div>